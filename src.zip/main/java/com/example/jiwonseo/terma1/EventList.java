package com.example.jiwonseo.terma1;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class EventList extends ArrayAdapter<Events> {
    private Activity context;
    private List<Events> eventsList;

    public EventList(Activity context, List<Events> eventsList) {
        super(context, R.layout.layout_events, eventsList);
        this.context = context;
        this.eventsList = eventsList;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();

        View listViewItem = inflater.inflate(R.layout.layout_events, null, true);

        TextView textViewTitle = (TextView) listViewItem.findViewById(R.id.txt_title);
        textViewTitle.setSelected(true);
        TextView textViewDate = (TextView) listViewItem.findViewById(R.id.txt_date);

        Events events = eventsList.get(position);

        textViewTitle.setText(events.title);
        textViewDate.setText(events.eventstartdate + "~" + events.eventenddate);

        return listViewItem;
    }
}
