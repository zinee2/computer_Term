package com.example.jiwonseo.terma1;

import android.support.v7.app.AppCompatActivity;

public class Ranking extends AppCompatActivity {
}
