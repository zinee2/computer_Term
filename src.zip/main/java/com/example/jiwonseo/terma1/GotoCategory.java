package com.example.jiwonseo.terma1;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class GotoCategory extends AppCompatActivity {
    public static int ACT_EDIT = 0;
    public TextView mText;
    public Button eventingbtn;
    public Button eventbeduebtn;
    public Button eventalmostendbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gotocategory);

        // "진행 중" button
        eventingbtn = (Button) findViewById(R.id.eventing);
        eventingbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(GotoCategory.this, EventIng.class));
            }
        });

        // "진행 예정" button
        eventbeduebtn = (Button) findViewById(R.id.eventbedue);
        eventbeduebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(GotoCategory.this, EventBedue.class));
            }
        });

        // "종료 임박" button
        eventalmostendbtn = (Button) findViewById(R.id.eventalmostend);
        eventalmostendbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(GotoCategory.this, EventAlmostEnd.class));
            }
        });
    }


}
