package com.example.jiwonseo.terma1;

public class Events {
    String title;
    String eventstartdate;
    String eventenddate;
    String addr1;
    String tel;
    String firstimage1;
    String firstimage2;


    public Events() {}
    public Events(String title, String eventstartdate, String eventenddate, String addr1, String tel, String firstimage1, String firstimage2) {
        this.title = title;
        this.eventstartdate = eventstartdate;
        this.eventenddate = eventenddate;
        this.addr1 = addr1;
        this.tel = tel;
        this.firstimage1 = firstimage1;
        this.firstimage2 = firstimage2;
    }

}
