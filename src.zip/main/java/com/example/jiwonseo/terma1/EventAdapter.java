package com.example.jiwonseo.terma1;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class EventAdapter extends BaseAdapter {
    Context context;
    int layout;
    ArrayList<Events> events;
    LayoutInflater inf;

    public EventAdapter(Context context, int layout, ArrayList<Events> events) {
        this.context = context;
        this.layout = layout;
        this.events = events;
    }

    @Override
    public int getCount() {
        return events.size();
    }
    @Override
    public Object getItem(int position) {
        return events.get(position);
    }
    @Override
    public long getItemId(int position) {
        return position;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null)
            convertView = inf.inflate(layout, null);
        TextView title = (TextView) convertView.findViewById(R.id.txt_detailtitle);
        TextView eventstartdate = (TextView) convertView.findViewById(R.id.txt_detaileventstartdate);
        TextView eventenddate = (TextView) convertView.findViewById(R.id.txt_detaileventenddate);
        TextView slash = (TextView) convertView.findViewById(R.id.txt_slash);
        TextView addr = (TextView) convertView.findViewById(R.id.txt_detailaddr);
        TextView tel = (TextView) convertView.findViewById(R.id.txt_detailtel);
        //ImageView firstimage1 = (ImageView) convertView.findViewById(R.id.img_detailfirstimage1);

        Events event = events.get(position);
        title.setText(event.title);
        addr.setText(event.addr1);
        tel.setText(event.tel);
        Uri uri = Uri.parse(event.firstimage1);
        //firstimage1.setImageURI(uri);

        return convertView;
    }
}
