package com.example.jiwonseo.terma1;


import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class APIData {
    public static void main(String[] args) {
        String myKey = "LRL9nrG2rxP3ivUGLoy8K8NVdZWanDEh4JN0X26wq2XAqczf2vP6MftUskc7ZOSBXl75BjctsGLeNHN8yp7Tyw%3D%3D";
        //String clientSecret = "";
        int display = 5;
        try {
            String ServiceKey = URLEncoder.encode("지역축제", "utf-8");
            String apiURL = "http://api.visitkorea.or.kr/openapi/service/rest/KorService/areaCode?ServiceKey=ServiceKey&numOfRows=10&pageNo=1&MobileOS=ETC&MobileApp=TestApp&_type=json";

            URL url = new URL(apiURL);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
        } catch(Exception e) {};
    }

}
