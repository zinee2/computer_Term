package com.example.jiwonseo.terma1;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.net.URL;

public class MainActivity extends AppCompatActivity {
    //final static int ACT_EDIT = 0;
    public Button btn;
    public Button pointbtn;
    public Button rankingbtn;
    //public TextView mText;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Firebase의 Reference를 생성
        mDatabase = FirebaseDatabase.getInstance().getReference();
        TextView status1 = (TextView)findViewById(R.id.result);
        StrictMode.enableDefaults();

        // MainActivity에서 API에 대한 정보를 Database에 update하도록 설계

        // API 정보를 읽어오기 위한 보조변수들(Flag)
        boolean initem = false;
        boolean inresultCode = false;
        boolean inresultMsg = false;
        boolean innumOfRows = false;
        boolean inpageNo = false;
        boolean intotalCount = false;
        boolean incontentid = false;
        boolean incontenttypeid = false;
        boolean increatedtime = false;
        boolean inmodifiedtime = false;
        boolean intitle = false;
        boolean inaddr1 = false;
        boolean ineventstartdate = false;
        boolean ineventenddate = false;
        boolean intel = false;
        boolean infirstimage1 = false;
        boolean infirstimage2 = false;

        // API 정보를 저장하는 변수들
        String item = null;
        String resultCode = null;
        String resultMsg = null;
        String numOfRows = null;
        String pageNo = null;
        String totalCount = null;
        String contentid = null;
        String contenttypeid = null;
        String createdtime = null;
        String modifiedtime = null;
        String title = null;
        String addr1 = null;
        String eventstartdate = null;
        String eventenddate = null;
        String tel = null;
        String firstimage1 = null;
        int int_firstimage1 = 0;
        String firstimage2 = null;
        int int_firstimage2 = 0;

        // API url을 통해 API 정보를 읽어오는 과정
        String key = "I5MskgR6Ns%2FKHm5IxrUe9mc21b5ToiYjt%2FQ133ImobNTjdwZUn2syPQNNxw3vG%2Fk2iKTfLJ%2FZYKu3hQkNaN%2BHw%3D%3D";
        try {
            URL url = new URL("http://api.visitkorea.or.kr/openapi/service/rest/KorService/searchFestival?&MobileOS=ETC&MobileApp=TourApp&numOfRows=1000&ServiceKey=" + key);
            XmlPullParserFactory parserCreator = XmlPullParserFactory.newInstance();
            XmlPullParser parser = parserCreator.newPullParser();

            parser.setInput(url.openStream(), null);

            int parserEvent = parser.getEventType();
            //------------------------파싱 시작-----------------------------
            while (parserEvent != XmlPullParser.END_DOCUMENT) {
                switch(parserEvent) {
                    // 각 API 정보의 START_TAG를 발견하면 Flag를 true로 설정
                    case XmlPullParser.START_TAG:
                        if (parser.getName().equals("resultCode"))
                            inresultCode = true;
                        if (parser.getName().equals("resultMsg"))
                            inresultMsg = true;
                        if (parser.getName().equals("numOfRows"))
                            innumOfRows = true;
                        if (parser.getName().equals("pageNo"))
                            inpageNo = true;
                        if (parser.getName().equals("totalCount"))
                            intotalCount = true;
                        if (parser.getName().equals("contentid"))
                            incontentid = true;
                        if (parser.getName().equals("contenttypeid"))
                            incontenttypeid = true;
                        if (parser.getName().equals("createdtime"))
                            increatedtime = true;
                        if (parser.getName().equals("modifiedtime"))
                            inmodifiedtime = true;
                        if (parser.getName().equals("title"))
                            intitle = true;
                        if (parser.getName().equals("addr1"))
                            inaddr1 = true;
                        if (parser.getName().equals("eventstartdate"))
                            ineventstartdate = true;
                        if (parser.getName().equals("eventenddate"))
                            ineventenddate = true;
                        if (parser.getName().equals("tel"))
                            intel = true;
                        if (parser.getName().equals("firstimage1"))
                            infirstimage1 = true;
                        if (parser.getName().equals("firstimage2"))
                            infirstimage2 = true;
                        break;

                        // 각 API 정보를 발견하면 변수에 해당 정보 저장
                    // 저장이 끝나면 Flag를 false로 설정
                    case XmlPullParser.TEXT:
                        if (inresultCode) {
                            resultCode = parser.getText();
                            inresultCode = false;
                        }
                        if (inresultMsg) {
                            resultMsg = parser.getText();
                            inresultMsg = false;
                        }
                        if (innumOfRows) {
                            numOfRows = parser.getText();
                            innumOfRows = false;
                        }
                        if (inpageNo) {
                            pageNo = parser.getText();
                            inpageNo = false;
                        }
                        if (intotalCount) {
                            totalCount = parser.getText();
                            intotalCount = false;
                        }
                        if (incontentid) {
                            contentid = parser.getText();
                            incontentid = false;
                        }
                        if (incontenttypeid) {
                            contenttypeid = parser.getText();
                            incontenttypeid = false;
                        }
                        if (increatedtime) {
                            createdtime = parser.getText();
                            increatedtime = false;
                        }
                        if (inmodifiedtime) {
                            modifiedtime = parser.getText();
                            inmodifiedtime = false;
                        }
                        if (intitle) {
                            title = parser.getText();
                            intitle = false;
                        }
                        if (inaddr1) {
                            addr1 = parser.getText();
                            inaddr1 = false;
                        }
                        if (ineventstartdate) {
                            eventstartdate = parser.getText();
                            ineventstartdate = false;
                        }
                        if (ineventenddate) {
                            eventenddate = parser.getText();
                            ineventenddate = false;
                        }
                        if (intel) {
                            tel = parser.getText();
                            intel = false;
                        }
                        if (infirstimage1) {
                            firstimage1 = parser.getText();
                            int_firstimage1 = Integer.parseInt(firstimage1);
                            infirstimage1 = false;
                        }
                        if (infirstimage2) {
                            firstimage2 = parser.getText();
                            int_firstimage2 = Integer.parseInt(firstimage2);
                            infirstimage2 = false;
                        }
                        break;

                        // 각 API의 END_TAG를 만나면 필요한 정보들만 Firebase에 저장
                    // Firebase에 정보를 저장하는 함수는 밑에 기입됨
                    case XmlPullParser.END_TAG:
                        if (parser.getName().equals("item")) {
                            //status1.setText(status1.getText() + "이름 : " + title + "\n주소 : " + addr1 + "\n시작날짜 : " + eventstartdate + "\n종료날짜 : " + eventenddate + "\n주소 : " + addr1 + "\n전화번호 : " + tel + "\n---------------------------------\n");
                            writeNewEvent(title, eventstartdate, eventenddate, addr1, tel, firstimage1, firstimage2);
                            initem = false;
                        }
                        break;
                }
                parserEvent = parser.next();
            }

        } catch(Exception e) { /*status1.setText("Error...What the hell");*/ }

        // 축제 찾아보기 button
        btn = (Button) findViewById(R.id.category);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, GotoCategory.class));
            }
        });

        // Point button
        pointbtn = (Button) findViewById(R.id.point);
        pointbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, Point.class));
            }
        });

        // 순위 button
        rankingbtn = (Button) findViewById(R.id.ranking);
        rankingbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, Ranking.class));
            }
        });


    }

    // Firebase에 정보를 저장하는 함수
    // Events class를 생성, 활용해 객체 형태로 정보들을 저장
    // 축제 이름, 축제 시작 날짜, 축제 종료 날짲, 주소, 전화번호를 저장
    private void writeNewEvent(String title, String eventstartdate, String eventenddate, String addr1, String tel, String firstimage1, String firstimage2) {
        Events events = new Events(title, eventstartdate, eventenddate, addr1, tel, firstimage1, firstimage2);
        mDatabase.child("Event").child(title).setValue(events);
    }

}

