package com.example.jiwonseo.terma1;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class EventBedue extends AppCompatActivity implements TextWatcher {
    FirebaseDatabase mdatabase;
    DatabaseReference dbref;
    ListView listViewEvents;
    ArrayList<Events> eventList;
    EditText editText;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eventbedue);
        mdatabase = FirebaseDatabase.getInstance();
        DatabaseReference dbref = mdatabase.getReference("Event");
        listViewEvents = (ListView) findViewById(R.id.listViewEvents);
        editText=(EditText)findViewById(R.id.editText);
        eventList = new ArrayList<>();

        EventAdapter eventAdapter = new EventAdapter(getApplicationContext(), R.layout.layout_events, eventList);


        listViewEvents.setAdapter(eventAdapter);
        listViewEvents.setTextFilterEnabled(true);
        editText.addTextChangedListener(this);
        listViewEvents.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(), EventDetail.class);
                intent.putExtra("title", eventList.get(position).title);
                intent.putExtra("addr", eventList.get(position).addr1);
                intent.putExtra("tel", eventList.get(position).tel);

                startActivity(intent);
            }

        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        mdatabase = FirebaseDatabase.getInstance();
        dbref = mdatabase.getReference("Event");

        dbref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                eventList.clear();
                for (DataSnapshot eventsSnapshot : dataSnapshot.getChildren()) {
                    Events events = eventsSnapshot.getValue(Events.class);

                    SimpleDateFormat mSimpleDateFormat = new SimpleDateFormat("yyyyMMdd", Locale.KOREA);
                    Date currentTime = new Date();
                    String mTime = mSimpleDateFormat.format(currentTime);
                    int int_currentTime = Integer.parseInt(mTime);
                    String eventStartDate = events.eventstartdate;
                    int int_eventStartDate = Integer.parseInt(eventStartDate);
                    if (int_currentTime < int_eventStartDate)
                        eventList.add(events);

                }
                EventList adapter = new EventList(EventBedue.this, eventList);
                if (adapter != null)
                    listViewEvents.setAdapter(adapter);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        listViewEvents.setFilterText(editText.getText().toString());

    }

    @Override
    public void afterTextChanged(Editable s) {
        if(editText.getText().length()==0) {
            listViewEvents.clearTextFilter();
        }

    }
}
